export const extractFirstLetter = (str: string) => str.charAt(0);
