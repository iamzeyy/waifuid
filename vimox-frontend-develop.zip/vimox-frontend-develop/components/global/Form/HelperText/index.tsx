import { HelperTextStyled } from './styled';

export type HelperTextProps = {
  error?: boolean;
};

export const HelperText = HelperTextStyled;
