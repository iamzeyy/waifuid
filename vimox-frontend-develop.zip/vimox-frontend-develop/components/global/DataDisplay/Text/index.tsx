import { TypographyBase } from '@components/DataDisplay/TypographyBase';

export const Text = TypographyBase;
