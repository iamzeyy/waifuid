import styled from 'styled-components';

export const AccessDeniedBox = styled.div`
  margin: 80px 0;
  text-align: center;
`;
