import type { State } from './types';

export const initialState: State = {
  searchFinder: {
    visible: false,
  },
};
