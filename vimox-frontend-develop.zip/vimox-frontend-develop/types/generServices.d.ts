export interface Gener {
  _id: string;
  name: string;
  createdAt: string;
}
